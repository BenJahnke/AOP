/*
 * @(#) MyExecute.java
 *
 */
package pkg4;

public @interface MyExecute {

}
